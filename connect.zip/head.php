<?php
$head="<div class='main-url'>
<a href='index.php' style='margin-right: 15px;'>Главная</a>
<ul class='topmenu'>
<li style='margin-right: 15px;'>
    <div style='display:flex; flex-direction:row; float:right;'>Контакты</div>
        <div class=submenu style='padding-bottom: 7px; padding-left:5px; padding-top:5px;'>
        Алишер:+7(999)647-04-27 <br>
        Роман:+7(999)724-52-37 <br></div>
</li>
</ul>
<a href='about.php'>О нас</a>
</div>";