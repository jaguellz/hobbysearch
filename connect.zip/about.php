<head>
    <meta charset="utf-8">
    <link rel="icon" href="https://www.flaticon.com/premium-icon/icons/svg/613/613307.svg">
</head>

<h1>МЫ МОЛОДЦЫ</h1>